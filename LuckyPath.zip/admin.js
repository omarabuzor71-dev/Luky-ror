function loginAdmin(){
 if(document.getElementById('pass').value!=='9999')return alert('خطأ');
 let o=JSON.parse(localStorage.getItem('orders')||'[]');
 let d=document.getElementById('orders');d.innerHTML='';
 o.forEach(x=>{if(x.status=='pending')d.innerHTML+=x.user+' '+x.amount+'<br>'});
}