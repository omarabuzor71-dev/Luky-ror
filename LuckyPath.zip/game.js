let coins=0,level=1,vip='Normal',username='';
function login(){
 username=document.getElementById('usernameInput').value;
 localStorage.setItem('user',username);
 document.getElementById('loginBox').classList.add('hidden');
 document.getElementById('appBox').classList.remove('hidden');
 document.getElementById('username').innerText=username;
}
function logout(){localStorage.clear();location.reload();}
document.getElementById('playBtn').onclick=()=>{
 let win=Math.random()>0.5?50:0;
 coins+=win;
 document.getElementById('coins').innerText=coins;
}
function requestPayment(a){
 let r=prompt('حوّل على 39995590 وادخل رقم العملية');
 let o=JSON.parse(localStorage.getItem('orders')||'[]');
 o.push({user:username,amount:a,ref:r,status:'pending'});
 localStorage.setItem('orders',JSON.stringify(o));
 alert('تم الإرسال');
}